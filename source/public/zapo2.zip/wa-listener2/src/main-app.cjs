const { app, BrowserWindow, ipcMain, Tray, Menu, Notification, nativeImage, shell } = require("electron");
const path = require("path");
const fs = require("fs");
const QRCode = require("qrcode");
const { Client, LocalAuth, MessageMedia } = require("whatsapp-web.js");

let win, tray, waClient;
let cfgCache = null;
let messagesCache = null; // [{id, ts, autor, telefone, grupo, mensagem, matched, chat_id}]
let templatesCache = null; // [{id, nome, chave, banco, tipo, texto}]
let waState = { status: "disconnected", qr: null, info: null };
let logs = [];

const UPDATE_URL = "https://ttnpouzoswhhqvedvngx.supabase.co/storage/v1/object/public/zapo2-updates/version.json";
const RESTART_FILES = new Set(["main-app.cjs", "preload.cjs"]);
const appUpdateDir = () => path.join(dataDir(), "app-update");
const versionFile = () => path.join(appUpdateDir(), ".version");

function dataDir() {
  const exeDir = path.dirname(app.getPath("exe"));
  const dir = path.join(exeDir, "wa-listener2-data");
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
}
const cfgPath = () => path.join(dataDir(), "config.json");
const msgPath = () => path.join(dataDir(), "messages.json");
const tplPath = () => path.join(dataDir(), "templates.json");

function readJson(p, fallback) {
  try { return JSON.parse(fs.readFileSync(p, "utf8")); } catch { return fallback; }
}
function writeJson(p, data) {
  try { fs.writeFileSync(p, JSON.stringify(data, null, 2)); } catch (e) { pushLog("error", "write " + p + ": " + e.message); }
}

function loadAll() {
  cfgCache = readJson(cfgPath(), {});
  messagesCache = readJson(msgPath(), []);
  templatesCache = readJson(tplPath(), []);
}
function getCfg() {
  if (!cfgCache) loadAll();
  return { groups: "", keywords: "", notify: "1", sound: "1", ...cfgCache };
}
function setCfg(patch) {
  cfgCache = { ...getCfg(), ...patch };
  writeJson(cfgPath(), cfgCache);
}

function pushLog(level, msg) {
  const entry = { ts: Date.now(), level, msg: String(msg).slice(0, 1000) };
  logs.push(entry);
  if (logs.length > 500) logs.shift();
  if (win && !win.isDestroyed()) win.webContents.send("log", entry);
}
function broadcastState() {
  if (win && !win.isDestroyed()) win.webContents.send("wa-state", waState);
}

function pickFile(name, bundled) {
  const updated = path.join(appUpdateDir(), name);
  try { if (fs.existsSync(updated)) return updated; } catch {}
  return bundled;
}
function iconPath()    { return pickFile("icon.png", path.join(__dirname, "ui", "icon.png")); }
function uiHtmlPath()  { return pickFile("index.html", path.join(__dirname, "ui", "index.html")); }
function preloadPath() { return pickFile("preload.cjs", path.join(__dirname, "preload.cjs")); }

function createWindow() {
  win = new BrowserWindow({
    width: 1080, height: 760, backgroundColor: "#06231a", autoHideMenuBar: true,
    title: "Zapo2",
    icon: iconPath(),
    webPreferences: { preload: preloadPath(), contextIsolation: true, nodeIntegration: false },
  });
  win.loadFile(uiHtmlPath());
  win.on("close", (e) => {
    if (!app.isQuitting) { e.preventDefault(); win.hide(); }
  });
}
function createTray() {
  let icon;
  try { icon = nativeImage.createFromPath(iconPath()).resize({ width: 16, height: 16 }); }
  catch { icon = nativeImage.createEmpty(); }
  tray = new Tray(icon);
  tray.setToolTip("Zapo2");
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: "Abrir Zapo2", click: () => win.show() },
    { type: "separator" },
    { label: "Sair", click: () => { app.isQuitting = true; app.quit(); } },
  ]));
  tray.on("click", () => win.show());
}

// ---- WhatsApp ----
function clearChromeLocks() {
  try {
    const sessRoot = path.join(dataDir(), "wa-session");
    if (!fs.existsSync(sessRoot)) return;
    const lockNames = ["SingletonLock", "SingletonCookie", "SingletonSocket", "DevToolsActivePort"];
    const walk = (dir) => {
      let entries = [];
      try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
      for (const e of entries) {
        const full = path.join(dir, e.name);
        if (e.isDirectory()) walk(full);
        else if (lockNames.includes(e.name)) { try { fs.rmSync(full, { force: true }); } catch {} }
      }
    };
    walk(sessRoot);
  } catch {}
}

function startWa() {
  if (waClient) return pushLog("warn", "Já existe cliente.");
  waState = { status: "starting", qr: null, info: null };
  broadcastState();
  pushLog("info", "Inicializando WhatsApp Web…");
  clearChromeLocks();

  waClient = new Client({
    authStrategy: new LocalAuth({ dataPath: path.join(dataDir(), "wa-session") }),
    puppeteer: { headless: true, args: ["--no-sandbox", "--disable-setuid-sandbox"] },
  });

  waClient.on("qr", async (qr) => {
    try {
      const dataUrl = await QRCode.toDataURL(qr, { margin: 1, width: 320 });
      waState = { status: "qr", qr: dataUrl, info: null };
      pushLog("info", "QR gerado.");
      broadcastState();
    } catch (e) { pushLog("error", "QR err: " + e.message); }
  });
  waClient.on("authenticated", () => pushLog("info", "Autenticado."));
  waClient.on("ready", () => {
    waState = { status: "connected", qr: null, info: { wid: waClient.info?.wid?.user } };
    pushLog("info", "Conectado: " + (waClient.info?.pushname || ""));
    broadcastState();
  });
  waClient.on("auth_failure", (m) => pushLog("error", "auth_failure: " + m));
  waClient.on("disconnected", (r) => {
    pushLog("warn", "Desconectado: " + r);
    waState = { status: "disconnected", qr: null, info: null };
    broadcastState();
    waClient = null;
  });
  waClient.on("message", async (msg) => {
    try { await handleMessage(msg); } catch (e) { pushLog("error", "msg err: " + e.message); }
  });

  waClient.initialize().catch((e) => {
    pushLog("error", "initialize: " + e.message);
    waState = { status: "error", qr: null, info: null };
    broadcastState();
    waClient = null;
  });
}
async function stopWa() {
  if (!waClient) return;
  try { await waClient.destroy(); } catch {}
  waClient = null;
  waState = { status: "disconnected", qr: null, info: null };
  broadcastState();
  pushLog("info", "Parado.");
}
async function logoutWa() {
  if (waClient) { try { await waClient.logout(); } catch {} waClient = null; }
  try { fs.rmSync(path.join(dataDir(), "wa-session"), { recursive: true, force: true }); pushLog("info", "Sessão removida."); } catch {}
  waState = { status: "disconnected", qr: null, info: null };
  broadcastState();
}

function parseList(s) { return String(s || "").split(/[\n,;]/).map((x) => x.trim()).filter(Boolean); }
function escapeRegex(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }

async function handleMessage(msg) {
  const cfg = getCfg();
  const groups = parseList(cfg.groups).map((g) => g.toLowerCase());
  const keywords = parseList(cfg.keywords);

  const chat = await msg.getChat().catch(() => null);
  if (!chat || !chat.isGroup) return;
  const groupName = (chat.name || "").toLowerCase();
  if (groups.length && !groups.some((g) => groupName.includes(g))) return;

  const body = msg.body || "";
  let matched = [];
  if (keywords.length) {
    matched = keywords.filter((p) => {
      const re = new RegExp(`(?:^|[^\\p{L}\\p{N}_])${escapeRegex(p)}(?=$|[^\\p{L}\\p{N}_])`, "iu");
      return re.test(body);
    });
    if (matched.length === 0) return;
  }

  const contact = await msg.getContact().catch(() => null);
  const entry = {
    id: msg.id?._serialized || (Date.now() + "_" + Math.random().toString(36).slice(2, 8)),
    ts: Date.now(),
    autor: contact?.pushname || contact?.name || contact?.number || "",
    telefone: contact?.number || "",
    grupo: chat.name || "",
    mensagem: body,
    matched,
    chat_id: chat.id?._serialized || "",
  };

  messagesCache.unshift(entry);
  if (messagesCache.length > 500) messagesCache.length = 500;
  writeJson(msgPath(), messagesCache);

  if (win && !win.isDestroyed()) win.webContents.send("msg-new", entry);

  // notificação nativa
  if (cfg.notify !== "0" && Notification.isSupported()) {
    try {
      const n = new Notification({
        title: `Zapo2 — ${entry.autor || entry.grupo}`,
        body: body.slice(0, 180),
        silent: cfg.sound === "0" || (cfg.soundType && cfg.soundType !== "system"),
        icon: iconPath(),
      });
      n.on("click", () => { if (win) { win.show(); win.focus(); } });
      n.show();
    } catch (e) { pushLog("warn", "notify: " + e.message); }
  }
  pushLog("info", `← ${chat.name}: ${body.slice(0, 80)}`);
}

// ---- send ----
async function listChats() {
  if (!waClient || waState.status !== "connected") return { ok: false, error: "não conectado" };
  try {
    const chats = await waClient.getChats();
    return {
      ok: true,
      chats: chats.map((c) => ({
        id: c.id?._serialized || "",
        name: c.name || c.formattedTitle || c.id?.user || "",
        isGroup: !!c.isGroup,
      })).filter((c) => c.id),
    };
  } catch (e) { return { ok: false, error: e.message }; }
}

async function sendMessageRaw({ chat_id, text, image_url, image_data }) {
  if (!waClient || waState.status !== "connected") throw new Error("não conectado");
  if (!chat_id) throw new Error("chat_id vazio");
  let media = null;
  if (image_data) {
    // image_data = "data:image/png;base64,...."
    const m = String(image_data).match(/^data:(.+?);base64,(.+)$/);
    if (m) media = new MessageMedia(m[1], m[2], "image");
  } else if (image_url) {
    try { media = await MessageMedia.fromUrl(image_url, { unsafeMime: true }); }
    catch (e) { pushLog("warn", "fromUrl: " + e.message); }
  }
  if (media) {
    await waClient.sendMessage(chat_id, media, text ? { caption: text } : {});
  } else {
    await waClient.sendMessage(chat_id, text || "");
  }
}

// ---- IPC ----
ipcMain.handle("cfg:get", () => getCfg());
ipcMain.handle("cfg:set", (_e, p) => { setCfg(p); return getCfg(); });
ipcMain.handle("wa:state", () => waState);
ipcMain.handle("wa:start", () => { startWa(); return true; });
ipcMain.handle("wa:stop", async () => { await stopWa(); return true; });
ipcMain.handle("wa:logout", async () => { await logoutWa(); return true; });
ipcMain.handle("wa:list-chats", () => listChats());
ipcMain.handle("wa:send", async (_e, p) => {
  try { await sendMessageRaw(p || {}); pushLog("info", `→ enviado ${p?.chat_id}`); return { ok: true }; }
  catch (e) { pushLog("error", "send: " + e.message); return { ok: false, error: e.message }; }
});
ipcMain.handle("msg:list", () => messagesCache || []);
ipcMain.handle("msg:remove", (_e, id) => {
  messagesCache = (messagesCache || []).filter((m) => m.id !== id);
  writeJson(msgPath(), messagesCache);
  return true;
});
ipcMain.handle("msg:clear", () => { messagesCache = []; writeJson(msgPath(), messagesCache); return true; });
ipcMain.handle("tpl:list", () => templatesCache || []);
ipcMain.handle("tpl:save", (_e, t) => {
  const tpl = { id: t.id || (Date.now() + "_" + Math.random().toString(36).slice(2, 6)), nome: t.nome || "", chave: t.chave || "", banco: t.banco || "", tipo: t.tipo || "", texto: t.texto || "" };
  templatesCache = templatesCache || [];
  const idx = templatesCache.findIndex((x) => x.id === tpl.id);
  if (idx >= 0) templatesCache[idx] = tpl; else templatesCache.unshift(tpl);
  writeJson(tplPath(), templatesCache);
  return tpl;
});
ipcMain.handle("tpl:remove", (_e, id) => {
  templatesCache = (templatesCache || []).filter((t) => t.id !== id);
  writeJson(tplPath(), templatesCache);
  return true;
});
ipcMain.handle("log:get", () => logs);
ipcMain.handle("log:clear", () => { logs = []; return true; });

function currentVersion() {
  try { return fs.readFileSync(versionFile(), "utf8").trim(); } catch { return ""; }
}
async function checkUpdate() {
  try {
    const r = await fetch(UPDATE_URL + "?t=" + Date.now(), { cache: "no-store" });
    if (!r.ok) return { ok: false, error: `HTTP ${r.status}` };
    const manifest = await r.json();
    const remote = String(manifest.version || "");
    const local = currentVersion();
    if (!remote) return { ok: false, error: "manifest sem version" };
    if (remote === local) return { ok: true, updated: false, version: remote };

    const dir = appUpdateDir();
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    const files = manifest.files || {};
    let needsRestart = false;
    for (const name of Object.keys(files)) {
      const f = files[name];
      const dest = path.join(dir, name);
      fs.mkdirSync(path.dirname(dest), { recursive: true });
      if (f.type === "text") {
        fs.writeFileSync(dest, String(f.content), "utf8");
      } else {
        fs.writeFileSync(dest, Buffer.from(f.content, "base64"));
      }
      if (RESTART_FILES.has(name)) needsRestart = true;
    }
    fs.writeFileSync(versionFile(), remote);
    pushLog("info", `Atualização aplicada: v${remote}${needsRestart ? " (restart)" : ""}`);
    return { ok: true, updated: true, version: remote, notes: manifest.notes || "", needsRestart };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}
ipcMain.handle("update:check", () => checkUpdate());
ipcMain.handle("app:reload", () => { if (win && !win.isDestroyed()) win.loadFile(uiHtmlPath()); return true; });
ipcMain.handle("app:restart", () => { app.isQuitting = true; app.relaunch(); app.exit(0); return true; });

app.whenReady().then(() => {
  loadAll();
  createWindow();
  createTray();
});
app.on("window-all-closed", (e) => { e.preventDefault?.(); });
