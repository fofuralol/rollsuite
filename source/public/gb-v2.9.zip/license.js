// License gate — runs before popup.js. Hides app until activated.
(function () {
  const VALIDATE_URL = "https://ttnpouzoswhhqvedvngx.supabase.co/functions/v1/validate-license";

  function $(id) { return document.getElementById(id); }

  async function getDeviceId() {
    return new Promise((res) => {
      chrome.storage.local.get(["__device_id"], (r) => {
        if (r.__device_id) return res(r.__device_id);
        const id = "dev_" + Math.random().toString(36).slice(2) + Date.now().toString(36);
        chrome.storage.local.set({ __device_id: id }, () => res(id));
      });
    });
  }

  function getLicense() {
    return new Promise((res) =>
      chrome.storage.local.get(["__license"], (r) => res(r.__license || null))
    );
  }

  function setLicense(v) {
    return new Promise((res) => chrome.storage.local.set({ __license: v }, res));
  }

  function showApp() {
    const g = $("licenseGate"); if (g) g.style.display = "none";
    const w = $("appWrap"); if (w) w.style.display = "";
  }

  function showGate() {
    const g = $("licenseGate"); if (g) g.style.display = "flex";
    const w = $("appWrap"); if (w) w.style.display = "none";
  }

  async function activate(serial) {
    const device_id = await getDeviceId();
    const device_info = navigator.userAgent.slice(0, 200);
    const r = await fetch(VALIDATE_URL, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ serial, device_id, device_info }),
    });
    return r.json();
  }

  document.addEventListener("DOMContentLoaded", async () => {
    const lic = await getLicense();
    if (lic && lic.ok && lic.serial) {
      showApp();
      return;
    }
    showGate();
    const btn = $("licActivate");
    const input = $("licSerial");
    const msg = $("licMsg");
    btn.addEventListener("click", async () => {
      const s = (input.value || "").trim().toUpperCase();
      if (!s) { msg.textContent = "Informe o serial."; return; }
      btn.disabled = true; msg.textContent = "Validando…";
      try {
        const res = await activate(s);
        if (res.ok) {
          await setLicense({ ok: true, serial: s, at: Date.now() });
          msg.textContent = "Ativado!";
          setTimeout(showApp, 400);
        } else {
          const map = {
            invalid_serial: "Serial inválido.",
            revoked: "Serial desativado.",
            device_mismatch: "Serial já vinculado a outra máquina.",
            missing_fields: "Dados incompletos.",
          };
          msg.textContent = map[res.reason] || "Falha na validação.";
        }
      } catch (e) {
        msg.textContent = "Erro de conexão.";
      } finally {
        btn.disabled = false;
      }
    });
  });
})();
