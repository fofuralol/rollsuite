// Offscreen document — captures tab video stream and detects pixel changes at high frequency
let stream = null;
let monitorInterval = null;
let video = null;
let canvas = null;
let ctx = null;
let prevPixelData = null;
let monitorTabId = null;
let monitorRegion = null; // { xRatio, yRatio, wRatio, hRatio }

const SAMPLE_INTERVAL = 30; // ms — ultra-fast polling
const CHANGE_THRESHOLD = 30; // minimum pixel value difference to count as change
const MIN_CHANGED_PIXELS = 3; // minimum pixels that must change
// Anti double-count: depois de detectar mudança, esperamos a região "estabilizar"
// (N frames consecutivos sem mudança) antes de aceitar a próxima detecção.
// Isso evita que o brilho/animação do slot ao pagar dispare múltiplos eventos.
const STABILIZATION_FRAMES = 6; // ~180ms de estabilidade exigida (6 * 30ms)
const POST_CHANGE_LOCKOUT_MS = 600; // tempo mínimo antes de aceitar próxima mudança
let lastChangeAt = 0;
let stableFrames = STABILIZATION_FRAMES;
let baselinePixelData = null; // baseline "estável" (não atualizada durante animação)

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "START_STREAM_MONITOR") {
    startMonitor(msg.streamId, msg.tabId, msg.region, sendResponse);
    return true;
  }
  if (msg.type === "STOP_STREAM_MONITOR") {
    stopMonitor();
    return false;
  }
  return false;
});

async function startMonitor(streamId, tabId, region, sendResponse) {
  stopMonitor(); // clean up any previous

  monitorTabId = tabId;
  monitorRegion = region;
  prevPixelData = null;

  try {
    stream = await navigator.mediaDevices.getUserMedia({
      audio: false,
      video: {
        mandatory: {
          chromeMediaSource: "tab",
          chromeMediaSourceId: streamId,
        },
      },
    });

    video = document.getElementById("vid");
    canvas = document.getElementById("cvs");
    ctx = canvas.getContext("2d", { willReadFrequently: true });

    video.srcObject = stream;
    await video.play();

    await new Promise((resolve) => {
      if (video.videoWidth > 0) return resolve();
      video.onloadedmetadata = resolve;
    });

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    monitorInterval = setInterval(samplePixels, SAMPLE_INTERVAL);
    console.log("[Offscreen] Monitoramento pixel iniciado a cada", SAMPLE_INTERVAL, "ms");
    if (sendResponse) sendResponse({ ok: true });
  } catch (e) {
    console.error("[Offscreen] Erro ao iniciar stream:", e);
    if (sendResponse) sendResponse({ ok: false, error: e.message });
  }
}

function countChanges(a, b) {
  let changed = 0;
  for (let i = 0; i < a.length; i += 4) {
    const dr = Math.abs(a[i] - b[i]);
    const dg = Math.abs(a[i + 1] - b[i + 1]);
    const db = Math.abs(a[i + 2] - b[i + 2]);
    if (dr + dg + db > CHANGE_THRESHOLD) changed++;
  }
  return changed;
}

function samplePixels() {
  if (!video || !ctx || !monitorRegion || video.videoWidth === 0) return;

  const vw = video.videoWidth;
  const vh = video.videoHeight;

  ctx.drawImage(video, 0, 0, vw, vh);

  const rx = Math.round(monitorRegion.xRatio * vw);
  const ry = Math.round(monitorRegion.yRatio * vh);
  const rw = Math.max(1, Math.round(monitorRegion.wRatio * vw));
  const rh = Math.max(1, Math.round(monitorRegion.hRatio * vh));

  const imageData = ctx.getImageData(rx, ry, rw, rh);
  const pixels = imageData.data;

  // Inicialização
  if (!baselinePixelData) {
    baselinePixelData = new Uint8ClampedArray(pixels);
    prevPixelData = new Uint8ClampedArray(pixels);
    return;
  }

  const now = Date.now();

  // Comparar com o frame anterior para detectar se a região está "em movimento"
  const changedFromPrev = countChanges(pixels, prevPixelData);
  const isMoving = changedFromPrev >= MIN_CHANGED_PIXELS;

  if (isMoving) {
    // Região mexendo (animação/brilho/transição em curso) — não conta nada agora
    stableFrames = 0;
  } else {
    stableFrames++;
  }

  // Comparar com a baseline estável para saber se houve mudança real
  const changedFromBaseline = countChanges(pixels, baselinePixelData);
  const sinceLast = now - lastChangeAt;

  // Só aceitamos uma nova contagem se:
  //   1. A região está estável agora (sem animação em curso)
  //   2. Tem diferença real vs. baseline anterior
  //   3. Já passou tempo suficiente desde a última contagem (lockout)
  if (
    stableFrames >= STABILIZATION_FRAMES &&
    changedFromBaseline >= MIN_CHANGED_PIXELS &&
    sinceLast >= POST_CHANGE_LOCKOUT_MS
  ) {
    lastChangeAt = now;
    baselinePixelData = new Uint8ClampedArray(pixels); // nova baseline
    chrome.runtime.sendMessage({
      type: "PIXEL_CHANGED",
      tabId: monitorTabId,
    });
  }

  prevPixelData = new Uint8ClampedArray(pixels);
}

function stopMonitor() {
  if (monitorInterval) {
    clearInterval(monitorInterval);
    monitorInterval = null;
  }
  if (stream) {
    stream.getTracks().forEach((t) => t.stop());
    stream = null;
  }
  if (video) {
    video.srcObject = null;
  }
  prevPixelData = null;
  baselinePixelData = null;
  stableFrames = STABILIZATION_FRAMES;
  lastChangeAt = 0;
  monitorTabId = null;
  console.log("[Offscreen] Monitoramento parado");
}
