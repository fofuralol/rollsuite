const $ = (id) => document.getElementById(id);

const SUPABASE_URL = "https://zgbybodkkakaswmaroko.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InpnYnlib2Rra2FrYXN3bWFyb2tvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQ2NDgyNjIsImV4cCI6MjA5MDIyNDI2Mn0.LFo6yOWrnx8bOBiwzQOdvpCrjYEflkVlVwjOcdSXY0M";
const DEFAULT_WEBHOOK_URL = "https://ttnpouzoswhhqvedvngx.supabase.co/functions/v1/meta-webhook?token=COLE_SEU_TOKEN_AQUI";

let currentTabId = null;
let currentHost = "";

// ── State ──
let mapping = { counterRegion: null, buttonPosition: null, continueButtonPosition: null };
let dashState = { userId: null, dbRowId: null, maeId: null, filhaId: null, tables: [], allData: null };

function storageKey() { return currentHost ? `mapping_${currentHost}` : "mapping"; }

function isCounterValid(r) { return r && r.width > 0 && r.height > 0; }
function isButtonValid(p) { return p && typeof p.x === "number" && typeof p.y === "number"; }

function saveMapping() {
  chrome.storage.local.set({ [storageKey()]: mapping });
}

function renderMapping() {
  const hasC = isCounterValid(mapping.counterRegion);
  const hasB = isButtonValid(mapping.buttonPosition);
  const hasContinue = isButtonValid(mapping.continueButtonPosition);
  $("counterInfo").style.display = hasC ? "flex" : "none";
  $("buttonInfo").style.display = hasB ? "flex" : "none";
  $("continueInfo").style.display = hasContinue ? "flex" : "none";
  if (hasC) {
    const r = mapping.counterRegion;
    $("counterInfoText").textContent = `Área mapeada ✔ (${Math.round(r.width)}×${Math.round(r.height)}px)`;
  }
  if (hasB) {
    const p = mapping.buttonPosition;
    $("buttonInfoText").textContent = `Botão parar ✔ (${Math.round(p.x)}, ${Math.round(p.y)})`;
  }
  if (hasContinue) {
    const p = mapping.continueButtonPosition;
    $("continueInfoText").textContent = `Botão continuar ✔ (${Math.round(p.x)}, ${Math.round(p.y)})`;
  }
  checkReady();
}

function getTargetSteps() {
  const tv = parseInt($("targetValue").value) || 0;
  return tv > 0 ? tv : 0;
}

function checkReady() {
  const targetSteps = getTargetSteps();
  const hasC = isCounterValid(mapping.counterRegion);
  const hasB = isButtonValid(mapping.buttonPosition);
  const ready = hasC && hasB && targetSteps > 0;

  $("startBtn").disabled = !ready;
  $("calcSteps").textContent = targetSteps;

  const missing = [];
  if (!hasC) missing.push("área");
  if (!hasB) missing.push("botão");
  if (targetSteps <= 0) missing.push("valores");

  if (missing.length > 0) {
    $("startBtn").textContent = `⚠ Falta: ${missing.join(", ")}`;
  } else {
    $("startBtn").textContent = "⚡ Iniciar Monitoramento";
  }
}

function showToast(text) {
  $("toast").textContent = text;
  $("toast").classList.add("show");
  setTimeout(() => $("toast").classList.remove("show"), 2000);
}

function send(msg, cb) {
  if (!currentTabId) return;
  try {
    chrome.tabs.sendMessage(currentTabId, msg, (res) => {
      if (chrome.runtime.lastError) { if (cb) cb(null); return; }
      if (cb) cb(res);
    });
  } catch (e) { if (cb) cb(null); }
}

// ── Storage change listener ──
chrome.storage.onChanged.addListener((changes) => {
  const key = storageKey();
  if (changes[key]) {
    const saved = changes[key].newValue;
    mapping.counterRegion = saved?.counterRegion || null;
    mapping.buttonPosition = saved?.buttonPosition || null;
    mapping.continueButtonPosition = saved?.continueButtonPosition || null;
    renderMapping();
  }
  if (changes.targetValue) {
    $("targetValue").value = changes.targetValue.newValue || "";
    checkReady();
  }
});

// ── Init ──
async function init() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  currentTabId = tab?.id;
  try { currentHost = tab?.url ? new URL(tab.url).hostname : ""; } catch (e) { currentHost = ""; }

  chrome.storage.local.get([storageKey(), "targetValue", "betValue", "showOverlay", "autoClickCount", "autoClickInterval"], (data) => {
    const saved = data[storageKey()];
    const hasSavedMapping = isCounterValid(saved?.counterRegion) && isButtonValid(saved?.buttonPosition);
    if (hasSavedMapping) {
      mapping.counterRegion = saved.counterRegion || null;
      mapping.buttonPosition = saved.buttonPosition || null;
      mapping.continueButtonPosition = saved.continueButtonPosition || null;
    } else {
      mapping = { counterRegion: null, buttonPosition: null, continueButtonPosition: null };
      chrome.storage.local.remove(storageKey());
    }
    if (data.targetValue) $("targetValue").value = data.targetValue;
    $("betValue").value = data.betValue != null ? data.betValue : 0.74;
    $("webhookUrl").value = data.webhookUrl || DEFAULT_WEBHOOK_URL;
    if (!data.webhookUrl) chrome.storage.local.set({ webhookUrl: DEFAULT_WEBHOOK_URL });
    if (data.autoClickCount != null) $("autoClickCount").value = data.autoClickCount;
    $("autoClickInterval").value = data.autoClickInterval != null ? data.autoClickInterval : 150;
    $("showOverlay").checked = !!data.showOverlay;
    renderMapping();
  });

  let retries = 0;
  function tryGetStatus() {
    send({ type: "GET_STATUS" }, (res) => {
      if (!res) {
        if (retries < 3) { retries++; setTimeout(tryGetStatus, 500); }
        return;
      }
      if (res.counterRegion) mapping.counterRegion = res.counterRegion;
      if (res.buttonPosition) mapping.buttonPosition = res.buttonPosition;
      if (Object.prototype.hasOwnProperty.call(res, "continueButtonPosition")) {
        mapping.continueButtonPosition = res.continueButtonPosition;
      }
      renderMapping();
      if (res.monitoring) setMonitorUI(true);
      if (res.hasStopped) {
        setMonitorUI(false);
        $("statusBar").className = "status-bar status-done";
        $("statusBar").innerHTML = "<span>✅ Meta atingida!</span>";
      }
      if (res.steps != null) updateLive(res.steps, res.targetSteps, res.initialValue);
    });
  }
  setTimeout(tryGetStatus, 300);

  // Poll live values
  setInterval(() => {
    send({ type: "GET_STATUS" }, (res) => {
      if (!res) return;
      if (res.monitoring || res.hasStopped) {
        updateLive(res.steps, res.targetSteps, res.initialValue);
      }
    });
  }, 200);
}

// ── Events ──
$("mapCounter").addEventListener("click", () => {
  send({ type: "PICK_COUNTER" }, (res) => { if (res?.ok) window.close(); });
});

$("mapButton").addEventListener("click", () => {
  send({ type: "PICK_BUTTON" }, (res) => { if (res?.ok) window.close(); });
});

// Continue button mapping removed (replaced by preset list)

$("clearMapping").addEventListener("click", () => {
  mapping = { counterRegion: null, buttonPosition: null, continueButtonPosition: null };
  saveMapping();
  renderMapping();
  send({ type: "CLEAR_MAPPING" });
  showToast("Mapeamento limpo");
});

$("toggleManual").addEventListener("click", () => {
  const sec = $("manualSection");
  sec.style.display = sec.style.display === "none" ? "block" : "none";
  if (mapping.counterRegion) {
    $("cX").value = Math.round(mapping.counterRegion.x) || "";
    $("cY").value = Math.round(mapping.counterRegion.y) || "";
    $("cW").value = Math.round(mapping.counterRegion.width) || "";
    $("cH").value = Math.round(mapping.counterRegion.height) || "";
  }
  if (mapping.buttonPosition) {
    $("bX").value = Math.round(mapping.buttonPosition.x) || "";
    $("bY").value = Math.round(mapping.buttonPosition.y) || "";
  }
  if (mapping.continueButtonPosition) {
    $("cbX").value = Math.round(mapping.continueButtonPosition.x) || "";
    $("cbY").value = Math.round(mapping.continueButtonPosition.y) || "";
  }
});

$("applyManual").addEventListener("click", () => {
  const cx = parseInt($("cX").value) || 0;
  const cy = parseInt($("cY").value) || 0;
  const cw = parseInt($("cW").value) || 0;
  const ch = parseInt($("cH").value) || 0;
  const bx = parseInt($("bX").value) || 0;
  const by = parseInt($("bY").value) || 0;
  const cbx = parseInt($("cbX").value) || 0;
  const cby = parseInt($("cbY").value) || 0;
  if (cw > 0 && ch > 0) {
    mapping.counterRegion = { x: cx, y: cy, width: cw, height: ch, xRatio: 0, yRatio: 0, wRatio: 0, hRatio: 0 };
  }
  if (bx > 0 || by > 0) {
    mapping.buttonPosition = { x: bx, y: by, xRatio: 0, yRatio: 0 };
  }
  if (cbx > 0 || cby > 0) {
    mapping.continueButtonPosition = { x: cbx, y: cby, xRatio: 0, yRatio: 0 };
  }
  saveMapping();
  send({ type: "SET_MAPPING", counterRegion: mapping.counterRegion, buttonPosition: mapping.buttonPosition, continueButtonPosition: mapping.continueButtonPosition });
  renderMapping();
  showToast("Coordenadas aplicadas ✔");
});

$("reloadMapping").addEventListener("click", () => {
  chrome.storage.local.get(null, (allData) => {
    const key = storageKey();
    let saved = allData[key];
    if (!saved) {
      for (const k of Object.keys(allData)) {
        if (k.startsWith("mapping_") && allData[k]?.counterRegion) {
          saved = allData[k];
          break;
        }
      }
    }
    if (saved) {
      mapping.counterRegion = saved.counterRegion || null;
      mapping.buttonPosition = saved.buttonPosition || null;
      mapping.continueButtonPosition = saved.continueButtonPosition || null;
      renderMapping();
      showToast("Mapeamento recarregado ✔");
    } else {
      showToast("Nenhum mapeamento encontrado");
    }
  });
});

$("targetValue").addEventListener("input", () => {
  chrome.storage.local.set({ targetValue: parseInt($("targetValue").value) || 0 });
  checkReady();
});


$("webhookUrl")?.addEventListener("input", () => {
  chrome.storage.local.set({ webhookUrl: $("webhookUrl").value.trim() });
});
$("toggleWebhook")?.addEventListener("click", () => {
  const row = $("webhookRow");
  row.style.display = row.style.display === "none" ? "block" : "none";
});
$("resetWebhook")?.addEventListener("click", () => {
  $("webhookUrl").value = DEFAULT_WEBHOOK_URL;
  chrome.storage.local.set({ webhookUrl: DEFAULT_WEBHOOK_URL });
  showToast("Webhook restaurado ✔");
});
$("betValue").addEventListener("input", () => {
  chrome.storage.local.set({ betValue: parseFloat($("betValue").value) || 0 });
});

$("showOverlay").addEventListener("change", () => {
  const checked = $("showOverlay").checked;
  chrome.storage.local.set({ showOverlay: checked });
  send({ type: "TOGGLE_OVERLAY", visible: checked });
});

$("testClick").addEventListener("click", () => {
  send({ type: "TEST_CLICK" }, (res) => {
    showToast(res?.ok ? "✓ Clique enviado!" : "✗ Nenhum botão");
  });
});

$("startBtn").addEventListener("click", () => {
  const targetSteps = getTargetSteps();
  if (targetSteps <= 0) return;
  const bet = parseFloat($("betValue").value) || 0;
  const rawCount = $("autoClickCount").value.trim();
  // Empty = unlimited (clica até parar). Use -1 sentinel for unlimited.
  const autoClickCount = rawCount === "" ? -1 : (parseInt(rawCount) || 0);
  const autoClickInterval = Math.max(50, parseInt($("autoClickInterval").value) || 150);
  send({ type: "START_MONITOR", targetSteps, initialValue: 0, betValue: bet, autoClickCount, autoClickInterval }, (res) => {
    if (res?.ok) {
      setMonitorUI(true);
      // Fecha o popup automaticamente ao iniciar (Chrome não permite "minimizar" popups)
      setTimeout(() => { try { window.close(); } catch (e) {} }, 150);
    }
  });
});

$("autoClickCount").addEventListener("input", () => {
  const v = $("autoClickCount").value.trim();
  chrome.storage.local.set({ autoClickCount: v === "" ? null : (parseInt(v) || 0) });
});
$("autoClickInterval").addEventListener("input", () => {
  chrome.storage.local.set({ autoClickInterval: parseInt($("autoClickInterval").value) || 150 });
});

$("stopBtn").addEventListener("click", () => {
  send({ type: "STOP_MONITOR" }, () => setMonitorUI(false));
});

// Messages from content script
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "COUNTER_MAPPED") {
    mapping.counterRegion = msg.region;
    saveMapping();
    renderMapping();
    showToast("Área mapeada ✔");
  }
  if (msg.type === "BUTTON_MAPPED") {
    mapping.buttonPosition = msg.position;
    saveMapping();
    renderMapping();
    showToast("Botão mapeado ✔");
  }
  if (msg.type === "CONTINUE_BUTTON_MAPPED") {
    mapping.continueButtonPosition = msg.position;
    saveMapping();
    renderMapping();
    showToast("Botão continuar mapeado ✔");
  }
  if (msg.type === "TARGET_REACHED") {
    
    $("statusBar").className = "status-bar status-done";
    $("statusBar").innerHTML = "<span>✅ Meta atingida! Jogo parado.</span>";
    setTimeout(() => {
      setMonitorUI(false);
      $("liveSection").style.display = "none";
    }, 3000);
  }
});

function setMonitorUI(active) {
  if (active) {
    $("statusBar").className = "status-bar status-active";
    $("statusBar").innerHTML = "<span>⚡ Monitorando giros...</span>";
    $("startBtn").style.display = "none";
    $("stopBtn").style.display = "block";
    $("liveSection").style.display = "block";
  } else {
    $("statusBar").className = "status-bar status-idle";
    $("statusBar").innerHTML = "<span>⏸ Parado</span>";
    $("startBtn").style.display = "block";
    $("stopBtn").style.display = "none";
  }
}

function updateLive(steps, targetSteps) {
  $("liveSection").style.display = "block";
  $("liveSteps").textContent = steps || 0;
  $("liveTarget").textContent = targetSteps || "-";
  const bet = parseFloat($("betValue").value) || 0;
  const estimated = (steps || 0) * bet;
  $("liveEstimated").textContent = estimated > 0 ? `R$ ${estimated.toFixed(2)}` : "-";
}

init();

// ── Toggle code visibility ──
$("toggleCodeVisibility").addEventListener("click", () => {
  const wrapper = $("shareCodeWrapper");
  const btn = $("toggleCodeVisibility");
  const hidden = wrapper.style.display === "none";
  wrapper.style.display = hidden ? "block" : "none";
  btn.textContent = hidden ? "👁 Ocultar" : "👁 Mostrar";
});


// ── Share / Import mapping code ──
function generateShareCode() {
  const hasC = isCounterValid(mapping.counterRegion);
  const hasB = isButtonValid(mapping.buttonPosition);
  const hasContinue = isButtonValid(mapping.continueButtonPosition);
  const section = $("shareSection");
  if (hasC || hasB || hasContinue) {
    const data = {};
    if (hasC) data.c = mapping.counterRegion;
    if (hasB) data.b = mapping.buttonPosition;
    if (hasContinue) data.cb = mapping.continueButtonPosition;
    const code = btoa(JSON.stringify(data));
    $("shareCode").value = code;
    section.style.display = "block";
  } else {
    section.style.display = "none";
  }
}

$("copyCode").addEventListener("click", () => {
  $("shareCode").select();
  navigator.clipboard.writeText($("shareCode").value).then(() => {
    showToast("Código copiado! ✔");
  }).catch(() => {
    document.execCommand("copy");
    showToast("Código copiado! ✔");
  });
});

$("toggleImport").addEventListener("click", () => {
  const sec = $("importSection");
  const open = sec.style.display === "none";
  sec.style.display = open ? "block" : "none";
  if (!open) {
    $("importHint").style.display = "none";
    $("applyImport").disabled = !$("importCode").value.trim();
  }
});

function updateImportState() {
  const hasCode = !!$("importCode").value.trim();
  $("applyImport").disabled = !hasCode;
  $("importHint").style.display = hasCode ? "block" : "none";
}

$("importCode").addEventListener("input", updateImportState);
$("importCode").addEventListener("paste", () => {
  setTimeout(updateImportState, 0);
});
$("importCode").addEventListener("keydown", (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key === "Enter" && !$("applyImport").disabled) {
    $("applyImport").click();
  }
});

$("applyImport").addEventListener("click", () => {
  const code = $("importCode").value.trim();
  if (!code) { showToast("Cole um código primeiro"); return; }
  try {
    const data = JSON.parse(atob(code));
    if (data.c) mapping.counterRegion = data.c;
    if (data.b) mapping.buttonPosition = data.b;
    if (data.cb) mapping.continueButtonPosition = data.cb;
    saveMapping();
    // Push mapping to content script so it takes effect immediately
    send({ type: "SET_MAPPING", counterRegion: mapping.counterRegion, buttonPosition: mapping.buttonPosition, continueButtonPosition: mapping.continueButtonPosition });
    renderMapping();
    generateShareCode();
    showToast("Mapeamento importado ✔");
    $("importCode").value = "";
    $("importHint").style.display = "none";
    $("applyImport").disabled = true;
    $("importSection").style.display = "none";
  } catch (e) {
    showToast("Código inválido ✗");
  }
});

// Update share code whenever mapping changes
const origRenderMapping = renderMapping;
renderMapping = function() {
  origRenderMapping();
  generateShareCode();
};

// ── Collapsible sections ──
$("toggleMappingSection").addEventListener("click", () => {
  const c = $("mappingContent");
  const open = c.style.display !== "none";
  c.style.display = open ? "none" : "block";
  $("mappingChevron").textContent = open ? "▸" : "▾";
});


// ── Mapping presets (lista no lugar do antigo botão Continuar) ──
const MAPPING_PRESETS = {
  bikini5: {
    label: "Bikini 5 telas",
    code: "eyJjIjp7IngiOjEzOCwieSI6MTk3NCwid2lkdGgiOjg4LCJoZWlnaHQiOjUxLCJ4UmF0aW8iOjAuMTc1NTcyNTE5MDgzOTY5NDUsInlSYXRpbyI6MC45NjU3NTM0MjQ2NTc1MzQyLCJ3UmF0aW8iOjAuMTExOTU5Mjg3NTMxODA2NjIsImhSYXRpbyI6MC4wMjQ5NTEwNzYzMjA5MzkzMzN9LCJiIjp7IngiOjcwLCJ5IjoxMDA1LCJ4UmF0aW8iOjAuMDg5MDU4NTI0MTczMDI4LCJ5UmF0aW8iOjAuNDkxNjgyOTc0NTU5Njg2OX19",
  },
};

function applyMappingCode(code) {
  try {
    const data = JSON.parse(atob(code));
    if (data.c) mapping.counterRegion = data.c;
    if (data.b) mapping.buttonPosition = data.b;
    if (data.cb) mapping.continueButtonPosition = data.cb;
    saveMapping();
    send({
      type: "SET_MAPPING",
      counterRegion: mapping.counterRegion,
      buttonPosition: mapping.buttonPosition,
      continueButtonPosition: mapping.continueButtonPosition,
    });
    renderMapping();
    return true;
  } catch (e) {
    return false;
  }
}

const presetSelect = $("presetMappingSelect");
if (presetSelect) {
  presetSelect.addEventListener("change", () => {
    const key = presetSelect.value;
    if (!key) return;
    const preset = MAPPING_PRESETS[key];
    if (!preset) return;
    if (applyMappingCode(preset.code)) {
      const targetSteps = getTargetSteps();
      if (targetSteps <= 0) {
        showToast(`Preset OK ✔ — preencha a Meta para iniciar`);
        $("targetValue").focus();
      } else {
        showToast(`Preset aplicado: ${preset.label} ✔`);
      }
    } else {
      showToast("Erro ao aplicar preset ✗");
    }
    presetSelect.value = "";
  });
}
